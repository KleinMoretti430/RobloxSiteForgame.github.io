// Кнопка "Перейти к игре"
document.getElementById('goto-game').addEventListener('click', function() {
    window.location.href = 'game.html';
});
